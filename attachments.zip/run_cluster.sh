#!/bin/bash
PY=/usr/bin/python3.12
export PYSPARK_PYTHON=$PY PYSPARK_DRIVER_PYTHON=$PY
exec spark-submit --master spark://10.3.19.170:7077 \
  --driver-memory 2g --executor-memory 6g --total-executor-cores 8 \
  --conf spark.driver.host=10.3.19.170 \
  --conf spark.executorEnv.PYSPARK_PYTHON=$PY \
  --packages org.mongodb.spark:mongo-spark-connector_2.13:11.1.0 "$@"
