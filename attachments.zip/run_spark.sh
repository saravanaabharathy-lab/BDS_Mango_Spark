#!/bin/bash
# usage: ./run_spark.sh myscript.py
spark-submit --master "local[*]" --driver-memory 4g \
  --packages org.mongodb.spark:mongo-spark-connector_2.13:11.1.0 "$@"
